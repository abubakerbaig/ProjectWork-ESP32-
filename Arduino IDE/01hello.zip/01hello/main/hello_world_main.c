#define LOG_LOCAL_LEVEL ESP_LOG_VERBOSE
#include "esp_log.h"

#include <stdio.h>
#include "sdkconfig.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

TaskHandle_t task1_handle;

int count=0;

void task1(void *data)
{
    ESP_LOGD("C-DAC: Task1", "Task1  started\n");
    vTaskDelete(task1_handle);
}


void app_main(void)
{

    xTaskCreate(task1, "cdac_task1", 2048, NULL, 5, &task1_handle);

    while (1)
    {
        ESP_LOGD("C-DAC: Main", "Main task counting: %d\n", count++);
        vTaskDelay(1000/portTICK_PERIOD_MS);
    }    
}